package com.example.okhttp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {


    TextView text1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text1 = (TextView) findViewById(R.id.textView);
    }
    //버튼을 누르면 thread발생시킴
    public void connectServerBtn(View view){
        NetworkTread thread = new NetworkTread();
        thread.start();
    }


    //네트워크 처리담당 쓰레드
    class NetworkTread extends Thread {
        @Override
        public void run() {
            super.run();

            //클라이언트 객체를 생성
            OkHttpClient client = new OkHttpClient();
            //클라이언드 객체에 정보를 셋팅하는 빌더를 생성한다.
            Request.Builder builder = new Request.Builder();
            //요청할 페이지의 주소를 셋팅한다.
            builder = builder.url("http://google.com");

            //요청한다.
            Request request = builder.build();
            Call call = client.newCall(request);
            NetworkCallback callback = new NetworkCallback();
            call.enqueue(callback);
        }
    }

    //응답결과가 수신되면 반응하는 콜백
    class NetworkCallback implements Callback {
        //네트워크 통신에 오류가 발생하면 호출되는 메서드
        @Override
        public void onFailure(Call call, IOException e) {

        }

        //응답결과가 정상적으로 수신되었을 때 호출되는 메서드
        @Override
        public void onResponse(Call call, Response response) throws IOException {
            //응답 결과를 수신한다.
            try {
                final String result = response.body().string();
                //화면갱신을 한다
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        text1.setText(result);
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}