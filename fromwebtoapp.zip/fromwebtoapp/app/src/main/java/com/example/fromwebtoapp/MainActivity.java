package com.example.fromwebtoapp;


import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    private ImageView ivImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivImage = findViewById(R.id.iv_image);

        // Glide로 이미지 표시하기
        String imageUrl = "https://weekly.chosun.com/up_fd/wc_news/2586/bimg_org/2586_58.jpg";
        Glide.with(this).load(imageUrl).into(ivImage);
    }
}
